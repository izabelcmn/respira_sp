# HANDOFF — Interface Streamlit (streamlit_app/)

Responsável: João. Esta pasta é a **interface** do Respira SP. É uma **ilha**:
lê os artefatos do pipeline e **não importa nada** do pacote `taxifare/`/`respira_sp/`.
Mexer aqui não causa conflito de merge com o resto do time.

## O que é

Painel em Streamlit que serve o **LightGBM** ao vivo (carrega o `.pkl`, lê o CSV
operacional e prevê 24h de PM2.5). Páginas: Visão Geral, Previsão, Mapa, Histórico, Sobre.

## Como rodar

```bash
cd streamlit_app
pip install -r requirements.txt   # streamlit, plotly, lightgbm, joblib, scikit-learn
streamlit run app.py              # http://localhost:8501
```

Abre mesmo sem os artefatos (modo demo sintético). Para servir o modelo real, os
três arquivos abaixo precisam existir.

## Contrato — os 3 artefatos que a UI lê (NÃO editar a UI para isso)

| Artefato | Caminho padrão | Quem gera |
|---|---|---|
| Modelo | `models/lightgbm_pm25.pkl` | pipeline de treino |
| Features (46, em ordem) | `models/lightgbm_features.pkl` | pipeline de treino |
| Dados operacionais | `data/operational/dados_features_*.csv` | ingestão (OpenAQ+OpenMeteo) |

- Caminhos resolvem a partir da **raiz do repo** (pai de `streamlit_app/`).
  Para apontar para outro lugar: `export RESPIRA_MODELS_DIR=...` e `export RESPIRA_OP_DIR=...`.
- O CSV é lido pelo **mais recente** que casar com `dados_features*.csv`.
- Coluna-alvo: `MP2.5`. Índice datetime em **UTC**.
- A **fonte da verdade das features** é o `lightgbm_features.pkl` — NÃO o
  `params.FEATURE_NAMES` (que está com 30, desatualizado).

## Onde cada coisa mora (para evoluir)

- `utils/data.py` — carga do modelo, leitura do CSV, métricas, fallback. **Ponto de integração.**
- `utils/charts.py` — gráficos (observado×previsto, mapa, barras).
- `utils/styling.py` — cores (`PALETTE`), faixas de IQAr, gauge, CSS.
- `utils/assistant.py` — chat (regras; LLM Anthropic opcional via `secrets.toml`).
- `app.py` + `pages/` — telas.
- `LGBM_OPERATIONAL` / `BACKTEST_2019` em `utils/data.py` — métricas mostradas.

## Pendências conhecidas (placeholders — trocar quando houver fonte)

- Poluentes além do PM2.5 (PM10/O3/NO2/CO) em `app.py`: valores ilustrativos.
- Coordenadas das estações em `utils/data.stations()`: aproximadas; PM2.5 do mapa é demo.
- "Tempo real": a leitura atual usa o último ponto do CSV operacional. Para CETESB/OpenAQ
  ao vivo, ligar em `latest_reading()` / `stations()`.

## Regras para não quebrar o merge

- Não editar arquivos fora de `streamlit_app/`. Não editar o `.python-version`.
- Manter os `.pkl` fora do git se forem grandes (ver `.gitignore` desta pasta).
- Cards são `st.container(border=True)` — não envolver widgets em `<div>` manual
  (a div fecha sozinha entre chamadas de `st.markdown`).
